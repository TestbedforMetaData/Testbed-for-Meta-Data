<?php

namespace App\Controller;

class UploadController extends AppController {

    public function beforeFilter(\Cake\Event\Event $event)
    {
        parent::beforeFilter($event);
        
        $user = $this->Auth->user();
        
        if($user == null || $user["role"] != 1)
        {
            return $this->redirect(["controller" => "Home"]);
        }
    }
	
	public function index() 
	{
		if($this->request->is("post"))
		{
			echo "hi";
			$this->Upload->processUpload();
		}
	}
}
